import Placeholder from "./_Placeholder";
export default function About() {
  return <Placeholder title="About Us" />;
}

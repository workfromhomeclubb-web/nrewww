import Placeholder from "./_Placeholder";
export default function Gallery() {
  return <Placeholder title="Gallery" />;
}

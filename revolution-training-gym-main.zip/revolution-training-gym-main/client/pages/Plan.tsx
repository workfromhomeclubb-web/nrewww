import Placeholder from "./_Placeholder";
export default function Plan() {
  return <Placeholder title="Our Plan" />;
}

import Placeholder from "./_Placeholder";
export default function Contact() {
  return <Placeholder title="Contact" />;
}

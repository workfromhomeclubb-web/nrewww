import Placeholder from "./_Placeholder";
export default function Location() {
  return <Placeholder title="Our Location" />;
}
